package com.coderbdk.cvbuilder

class AndroidImagePicker: ImagePicker {
    override suspend fun pickImage(): String? {
        return null
    }
}