package com.coderbdk.cvbuilder

import com.coderbdk.cvbuilder.data.model.CVTemplate

class AndroidCVFileHandler: CVFileHandler {
    override suspend fun export(template: CVTemplate) {
        TODO("Not yet implemented")
    }

    override suspend fun import(): CVTemplate? {
        TODO("Not yet implemented")
    }
}